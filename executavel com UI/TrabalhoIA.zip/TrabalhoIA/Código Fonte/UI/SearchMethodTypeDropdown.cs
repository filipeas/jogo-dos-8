﻿using TMPro;
using UnityEngine;

[RequireComponent(typeof(TMP_Dropdown))]
public class SearchMethodTypeDropdown : MonoBehaviour {
    public  PuzzleBoardManager puzzleBoard;
    private TMP_Dropdown       _testGameDropdown;

    void Start() {
        _testGameDropdown = GetComponent<TMP_Dropdown>();
        
        if (puzzleBoard == null) {
            puzzleBoard = FindObjectOfType<PuzzleBoardManager>();
        }
        
        if (puzzleBoard != null) {
            _testGameDropdown.onValueChanged.AddListener(value => { puzzleBoard.SearchMethodType = (PuzzleBoardManager.SearchMethodTypes)value;});
        }
    }
}