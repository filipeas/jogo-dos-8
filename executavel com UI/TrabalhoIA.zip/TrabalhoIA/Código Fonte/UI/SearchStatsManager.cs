﻿using System;
using TMPro;
using UnityEngine;

public class SearchStatsManager : MonoBehaviour {
    public PuzzleBoardManager puzzleBoard;

    [Space]
    public TextMeshProUGUI custoCaminho;
    public TextMeshProUGUI custoEspaco;
    public TextMeshProUGUI custoTempo;
    public TextMeshProUGUI custoExecucao;

    private void Start() {
        if (puzzleBoard == null) {
            puzzleBoard = FindObjectOfType<PuzzleBoardManager>();
        }
    }

    private void Update() {
        if (puzzleBoard == null || puzzleBoard.SearchMethod == null) {
            return;
        }

        var search = puzzleBoard.SearchMethod;
        custoCaminho.text  = search.custoDeCaminho().ToString();
        custoEspaco.text   = search.custoDeEspaco().ToString();
        custoTempo.text    = search.custoDeTempo().ToString();
        custoExecucao.text = search.tempoExecutado().ToString(@"m\:ss\.fffff");
    }
}