﻿public static class PuzzleUtils {
    public static void EnsureSolvable(int[] puzzle) {
        if (IsSolvable(puzzle) == false) {
            for (var i = 0; i < puzzle.Length - 1; i++) {
                if (puzzle[i] == 0) {
                    continue;
                }

                if (puzzle[i + 1] == 0) {
                    ++i;
                    continue;
                }

                var temp = puzzle[i];
                puzzle[i] = puzzle[i + 1];
                puzzle[i + 1] = temp;
                break;
            }
        }
    }
    
    public static bool IsSolvable(int[] puzzle) {
        var invCount = 0;
        for (var i = 0; i < puzzle.Length; i++) {
            if (puzzle[i] == 0) {
                continue;
            }

            for (var j = i; j < puzzle.Length; j++) {
                if (puzzle[j] == 0) {
                    continue;
                }

                if (puzzle[i] > puzzle[j]) {
                    invCount++;
                }
            }
        }

        return invCount % 2 == 0;
    }
}