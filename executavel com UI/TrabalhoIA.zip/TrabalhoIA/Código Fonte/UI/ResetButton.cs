﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public class ResetButton : MonoBehaviour {
    public  TMP_Dropdown testGameDropdown;
    public  PuzzleBoardManager puzzleBoard;
    private Button             _button;

    private void Awake() {
        _button = GetComponent<Button>();
        
        if (puzzleBoard == null) {
            puzzleBoard = FindObjectOfType<PuzzleBoardManager>();
        }
        
        if (puzzleBoard == null) {
            _button.interactable = false;
        } else {
            _button.onClick.AddListener(() => { puzzleBoard.ResetBoard(4); });
        }
    }
}