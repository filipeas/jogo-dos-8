﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PuzzlePiece : MonoBehaviour {
    public int             Number { get; private set; }
    public TextMeshProUGUI text;
    public Button          button;

    private PuzzleBoardManager _manager;

    private void Awake() {
        text     = GetComponentInChildren<TextMeshProUGUI>(includeInactive: true);
        button   = GetComponentInChildren<Button>(includeInactive: true);
        _manager = GetComponentInParent<PuzzleBoardManager>();

        if (button != null) {
            button.onClick.AddListener(OnButtonClicked);
        }
    }

    private void OnButtonClicked() {
        _manager.TrySlide(this);
    }

    public void Set(int number) {
        Number = number;

        if (text != null) {
            text.text = number.ToString();
        }
        
        SetButtonActive(number != 0);
    }

    private void SetButtonActive(bool active) {
        if (button == null) {
            button = GetComponentInChildren<Button>(includeInactive: true);
        }
        
        button.gameObject.SetActive(active);
    }
}