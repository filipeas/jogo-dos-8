﻿using System;
using System.Collections.Generic;

public interface ISearchMethod {
    void buscar();

    int custoDeCaminho();

    int custoDeEspaco();

    int custoDeTempo();

    List<No> solucaoFinal();

    List<No> arvoreFinal();

    List<No> solucaoEscolhasDosPais();

    TimeSpan tempoExecutado();
}