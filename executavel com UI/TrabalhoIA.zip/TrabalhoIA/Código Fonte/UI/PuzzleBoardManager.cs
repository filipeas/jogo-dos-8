﻿using System;
using System.Collections.Generic;
using System.Linq;
using Puzzle_Search_Problem___Jogo_dos_8;
using UnityEngine;

public class PuzzleBoardManager : MonoBehaviour {
    private const int Rows    = 3;
    private const int Columns = 3;

    public float slideDuration      = 1.0f;
    public float stepByStepDuration = 3.0f;

    public PuzzlePiece[] puzzlePieces = new PuzzlePiece[Rows * Columns];

    public Dictionary<int, int> _numberToIndexLookup = new Dictionary<int, int>(Rows * Columns);

    public static int[] TestGame1 { get; } = {4, 1, 2, 0, 5, 3, 6, 7, 8};
    public static int[] TestGame2 { get; } = {0, 7, 2, 1, 4, 3, 6, 8, 5};
    public static int[] TestGame3 { get; } = {1, 2, 3, 4, 7, 5, 6, 8, 0};
    public static int[] TestGame4 { get; } = {0, 1, 2, 4, 5, 3, 6, 7, 8};

    private static   int[]  TargetGame { get; } = {1, 2, 3, 4, 0, 5, 6, 7, 8};
    private readonly int[]  _pieceNumbers = new int[Rows * Columns];
    private readonly int[]  _resetState = new int[Rows * Columns];
    private readonly int[,] _tempMatrix   = new int[Rows, Columns];

    private List<PuzzlePieceSlider> _pieceSliders;

    public enum SearchMethodTypes {
        Largura      = 0,
        Profundidade = 1,
        Gulosa       = 2,
        AStar        = 3,
    }

    private ISearchMethod _searchMethod;
    private List<No>      _solution;
    private int           _curNode;

    public ISearchMethod     SearchMethod     => _searchMethod;
    public SearchMethodTypes SearchMethodType { get; set; }

    private bool  _isShowingStepByStep;
    private float _accStepByStep;

    private void Start() {
        _pieceSliders = new List<PuzzlePieceSlider>();
        TestGame3.CopyTo(_resetState, 0);
        ResetBoard(0);
    }

    private void Update() {
        var slidingCount = 0;

        if (_isShowingStepByStep) {
            _accStepByStep += Time.deltaTime;
        } else {
            for (var index = 0; index < _pieceSliders.Count; index++) {
                if (_pieceSliders[index].IsSliding) {
                    slidingCount++;
                    _pieceSliders[index].Update(Time.deltaTime);
                }
            }
        }

        if (_solution != null && slidingCount == 0 && (_isShowingStepByStep == false || _accStepByStep >= stepByStepDuration)) {
            _accStepByStep = 0;
            var state = _solution[_curNode]._state;

            if (_isShowingStepByStep) {
                ConvertMatrixToState(state, _pieceNumbers);
                ResetBoard();
            } else {
                for (var i = 0; i < Rows; i++) {
                    for (var j = 0; j < Columns; j++) {
                        var stateIndex = i * Columns + j;
                        var curIndex   = _numberToIndexLookup[state[i, j]];

                        if (stateIndex != curIndex) {
                            Swap(curIndex, stateIndex);
                        }
                    }
                }
            }

            _curNode++;

            if (_curNode == _solution.Count) {
                _solution = null;
            }
        }
    }

    public void ResetBoard(int testGame = -1) {
        switch (testGame) {
            case 0:
                TargetGame.CopyTo(_pieceNumbers, 0);
                TargetGame.CopyTo(_resetState, 0);
                _solution = null;
                break;

            case 1:
                TestGame1.CopyTo(_pieceNumbers, 0);
                TestGame1.CopyTo(_resetState, 0);
                _solution = null;
                break;

            case 2:
                TestGame2.CopyTo(_pieceNumbers, 0);
                TestGame2.CopyTo(_resetState, 0);
                _solution = null;
                break;

            case 3:
                TestGame3.CopyTo(_pieceNumbers, 0);
                TestGame3.CopyTo(_resetState, 0);
                _solution = null;
                break;
            
            case 4:
                _resetState.CopyTo(_pieceNumbers, 0);
                _solution = null;
                break;
        }

        UpdatePieces();
    }

    public void Search() {
        var same = true;
        for (var i = 0; i < Columns * Rows; i++) {
            if (_pieceNumbers[i] != TargetGame[i]) {
                same = false;
                break;
            }
        }

        if (same) {
            return;
        }

        ConvertStateToMatrix(_pieceNumbers, _tempMatrix);
        var init = new No(_tempMatrix, null);

        ConvertStateToMatrix(TargetGame, _tempMatrix);
        var target = new No(_tempMatrix, null);

        _searchMethod = GetSearchMethod(SearchMethodType, init, target);
        _searchMethod.buscar();
        _solution = _searchMethod.solucaoFinal();
        _curNode             = 0;
        _isShowingStepByStep = false;
        _accStepByStep       = 0;
    }

    public void StepByStep() {
        ConvertStateToMatrix(_pieceNumbers, _tempMatrix);
        var init = new No(_tempMatrix, null);

        ConvertStateToMatrix(TargetGame, _tempMatrix);
        var target = new No(_tempMatrix, null);

        _searchMethod = GetSearchMethod(SearchMethodType, init, target);
        _searchMethod.buscar();
        _solution = _searchMethod.solucaoEscolhasDosPais();
        Program.printArvore(_solution);
        _curNode             = 0;
        _isShowingStepByStep = true;
        _accStepByStep       = 0;
    }

    private ISearchMethod GetSearchMethod(SearchMethodTypes searchMethodType, No init, No target) {
        switch (searchMethodType) {
            case SearchMethodTypes.Largura:      return new Largura(init, target);
            case SearchMethodTypes.Profundidade: return new Profundidade(init, target);
            case SearchMethodTypes.Gulosa:       return new Guloso(init, target);
            case SearchMethodTypes.AStar:        return new AStar(init, target);
            default:                             throw new ArgumentOutOfRangeException(nameof(searchMethodType), searchMethodType, null);
        }
    }

    private static void ConvertStateToMatrix(int[] from, int[,] to) {
        Debug.Assert(to.Length == from.Length);

        for (var i = 0; i < Rows; i++) {
            for (var j = 0; j < Columns; j++) {
                to[i, j] = from[i * Columns + j];
            }
        }
    }

    private static void ConvertMatrixToState(int[,] from, int[] to) {
        Debug.Assert(to.Length == from.Length);

        for (var i = 0; i < Rows; i++) {
            for (var j = 0; j < Columns; j++) {
                to[i * Columns + j] = from[i, j];
            }
        }
    }

    public void Shuffle() {
        FisherYatesShuffle.Shuffle(_pieceNumbers);
        PuzzleUtils.EnsureSolvable(_pieceNumbers);
        _pieceNumbers.CopyTo(_resetState, 0);
        
        UpdatePieces();
    }

    private void UpdatePieces() {
        Debug.Assert(PuzzleUtils.IsSolvable(_pieceNumbers));
        _numberToIndexLookup.Clear();

        for (var r = 0; r < Rows; r++) {
            for (var c = 0; c < Columns; c++) {
                var index = GetIndex(r, c);
                puzzlePieces[index].Set(_pieceNumbers[index]);
                _numberToIndexLookup.Add(_pieceNumbers[index], index);
            }
        }
    }

    public void TrySlide(PuzzlePiece piece) {
        var pieceIndex = _numberToIndexLookup[piece.Number];
        var zeroIndex  = _numberToIndexLookup[0];

        if (AreAdjacent(pieceIndex, zeroIndex)) {
            Swap(pieceIndex, zeroIndex);
        }
    }

    private bool AreAdjacent(PuzzlePiece pieceA, PuzzlePiece pieceB) {
        return AreAdjacent(_numberToIndexLookup[pieceA.Number], _numberToIndexLookup[pieceB.Number]);
    }

    private bool AreAdjacent(int indexA, int indexB) {
        var diff = Math.Abs(indexA - indexB);
        return diff / Columns == 1 && diff   % Columns == 0 ||
               diff           == 1 && indexA / Columns == indexB / Columns;
    }

    private void Swap(int indexA, int indexB) {
        // Debug.Assert(AreAdjacent(indexA, indexB));

        var temp = puzzlePieces[indexA];
        puzzlePieces[indexA] = puzzlePieces[indexB];
        puzzlePieces[indexB] = temp;

        var tempNum = _pieceNumbers[indexA];
        _pieceNumbers[indexA] = _pieceNumbers[indexB];
        _pieceNumbers[indexB] = tempNum;

        var pieceA = puzzlePieces[indexB];
        var pieceB = puzzlePieces[indexA];

        _numberToIndexLookup[pieceA.Number] = indexB;
        _numberToIndexLookup[pieceB.Number] = indexA;

        // _pieceSlider.Slide(pieceA, pieceB);
        var foundSlider = false;
        foreach (var slider in _pieceSliders) {
            if (slider.IsSliding == false) {
                slider.Slide(pieceA, pieceB);
                foundSlider = true;
                break;
            }
        }

        if (foundSlider == false) {
            _pieceSliders.Add(new PuzzlePieceSlider(pieceA, pieceB, slideDuration));
        }
    }

    private static int GetIndex(int row, int column) => row * Columns + column;
}