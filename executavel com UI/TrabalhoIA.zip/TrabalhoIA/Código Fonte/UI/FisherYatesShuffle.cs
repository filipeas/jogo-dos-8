﻿using System;
using System.Collections.Generic;

public class FisherYatesShuffle {
    static Random _random = new Random();

    public static void Shuffle<T>(IList<T> array) {
        var n = array.Count;
        for (var i = 0; i < n - 1; i++) {
            var r = i + _random.Next(n - i);
            var t = array[r];
            array[r] = array[i];
            array[i] = t;
        }
    }
}