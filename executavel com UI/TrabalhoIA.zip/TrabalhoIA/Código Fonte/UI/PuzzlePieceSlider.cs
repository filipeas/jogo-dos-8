﻿using System;
using UnityEngine;

public class PuzzlePieceSlider {
    private PuzzlePiece _pieceA;
    private PuzzlePiece _pieceB;
    private bool        _isSliding;
    private float       _duration;
    private float       _accTime;
    private Vector3     _posA;
    private Vector3     _posB;

    public bool IsSliding => _isSliding;

    public PuzzlePieceSlider(PuzzlePiece pieceA, PuzzlePiece pieceB, float duration = 1.0f) {
        _duration = duration;
        _accTime  = 0;

        _pieceA = pieceA;
        _posA   = pieceA.transform.position;

        _pieceB = pieceB;
        _posB   = pieceB.transform.position;

        _isSliding = true;
    }

    public PuzzlePieceSlider(float duration = 1.0f) {
        _duration  = duration;
        _accTime   = 0;
        _pieceA    = null;
        _pieceB    = null;
        _isSliding = false;
        _posA      = Vector3.zero;
        _posB      = Vector3.zero;
    }

    public void Slide(PuzzlePiece pieceA, PuzzlePiece pieceB, float? duration = null) {
        Reset();

        _pieceA = pieceA;
        _posA   = pieceA.transform.position;

        _pieceB = pieceB;
        _posB   = pieceB.transform.position;

        _isSliding = true;

        if (duration.HasValue) {
            _duration = duration.Value;
        }
    }

    public void Reset() {
        if (_isSliding) {
            _pieceA.transform.position = _posB;
            _pieceB.transform.position = _posA;
        }

        _isSliding = false;
        _accTime   = 0;
    }

    public void Update(float deltaTime) {
        if (_isSliding == false) {
            return;
        }

        if (_accTime < _duration) {
            _accTime += deltaTime;

            _pieceA.transform.position = Vector3.Lerp(_pieceA.transform.position, _posB, _accTime / _duration);
            _pieceB.transform.position = Vector3.Lerp(_pieceB.transform.position, _posA, _accTime / _duration);
        } else {
            _pieceA.transform.position = _posB;
            _pieceB.transform.position = _posA;

            _isSliding = false;
            _accTime   = 0;
        }
    }
}